import torch

model = torch.load("my_model.pth")
