import torch

x = torch.tensor([1, 2, 3])
print(x)
print(x.shape)
print(x.dtype)
