import torch
print(torch.cuda.is_available())
