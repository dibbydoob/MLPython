import torch
a = torch.ones(2,3,4)
print(a)
