import torch
b = torch.sqrt(a)
print(b)
print(torch.isnan(b))
