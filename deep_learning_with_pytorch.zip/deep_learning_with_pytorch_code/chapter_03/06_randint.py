import torch
a = torch.randint(10, size=(3,4))
print(a)
