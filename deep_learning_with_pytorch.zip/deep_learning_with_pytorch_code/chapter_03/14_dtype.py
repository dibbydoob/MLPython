import torch
a = torch.zeros(2, 3, 4)
print(a.dtype)
