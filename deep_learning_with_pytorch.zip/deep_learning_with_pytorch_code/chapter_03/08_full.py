import torch
a = torch.full((2,3,4), 5)
print(a)
