import torch
a = torch.randn(3,4,5)
print(a)
