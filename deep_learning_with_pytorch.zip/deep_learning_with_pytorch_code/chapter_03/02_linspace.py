import torch
a = torch.linspace(-1, 1, 10)
print(a)
