import torch
a = torch.tensor([[1,2,3], [4,5,6]], dtype=torch.int32)
print(a)
