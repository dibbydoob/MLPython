import torch
a = torch.rand(3,4)
print(a)
