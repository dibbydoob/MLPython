import torch
a = torch.eye(4)
print(a)
