import torch
a = torch.randint(3, 10, size=(3,4))
print(a)
