import numpy as np
data = np.loadtxt("pima-indians-diabetes.csv", delimiter=",")
