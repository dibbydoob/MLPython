# check deep learning version numbers
# pytorch
import torch
print('pytorch: %s' % torch.__version__)
# torchvision
import torchvision
print('torchvision: %s' % torchvision.__version__)
