# show preferred channel order
from keras import backend
print(backend.image_data_format())