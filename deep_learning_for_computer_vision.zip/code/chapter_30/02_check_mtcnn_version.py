# confirm mtcnn was installed correctly
import mtcnn
# print version
print(mtcnn.__version__)