# manually apply a 1d filter
from numpy import asarray
print(asarray([0, 1, 0]).dot(asarray([0, 0, 0])))