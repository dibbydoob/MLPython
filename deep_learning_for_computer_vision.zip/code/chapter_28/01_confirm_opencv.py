# check opencv version
import cv2
# print version number
print(cv2.__version__)