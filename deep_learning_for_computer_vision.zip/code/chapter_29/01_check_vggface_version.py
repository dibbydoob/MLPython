# check version of keras_vggface
import keras_vggface
# print version
print(keras_vggface.__version__)