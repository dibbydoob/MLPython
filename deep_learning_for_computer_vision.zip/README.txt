Deep Learning for Computer Vision
=================================

README
------

Welcome to Deep Learning for Computer Vision!

Your package contains:

1. README (this file)
	README.txt
2. The Ebook:
	deep_learning_for_computer_vision.pdf
3. Code Recipes:
	code/

The code directory provides access to all of the data and code examples used in the book.

Any questions at all, contact me directly via email: jason@MachineLearningMastery.com

Kind Regards,

Jason.