Optimization for Machine Learning
=================================

README
------

Welcome to Optimization for Machine Learning!

Your download contains:

1. The Ebook:
	optimization_for_machine_learning.pdf
2. Sample Code:
	code/

Keep your receipt email, you can use it to re-download your book any time in the future.

Any questions at all, contact me directly via email: jason@MachineLearningMastery.com

Kind Regards,

Jason.
