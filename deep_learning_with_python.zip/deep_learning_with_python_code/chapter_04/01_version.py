import tensorflow
print(tensorflow.__version__)
