import numpy as np

polynomial = np.poly1d([1, 2, 3])
print(polynomial)
