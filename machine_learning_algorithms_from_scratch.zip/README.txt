Machine Learning Algorithms From Scratch
========================================

README
------

Welcome to Machine Learning Algorithms From Scratch!

Your package contains:

1. README (this file)
	README.txt
2. The Ebook:
	machine_learning_algorithms_from_scratch.pdf
3. Sample Code:
	code/

The code directory provides access to all of the data and code examples used in the book.

Keep your receipt email, you can use it to re-download your book any time in the future.

Any questions at all, contact me directly via email: jason@MachineLearningMastery.com

Kind Regards,

Jason.

