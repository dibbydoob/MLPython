if a < -5 or a > 5 or -2 < a < 2:
    print("abs(a) is not in 2 to 5")
