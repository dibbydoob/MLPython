months = ["January", "February", "March", "April", "May", "June", "July",
          "August", "September", "October", "November", "December"]

X = sorted(months, key=len)
print(X)
# ['May', 'June', 'July', 'March', 'April', 'August', 'January', 'October',
#  'February', 'November', 'December', 'September']
