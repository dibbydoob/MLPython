planets = [
    "Mercury",
    "Venus"  ,
    "Earth"  ,
    "Mars"   ,
    "Jupiter",
    "Saturn" ,
    "Uranus" ,
    "Neptune",
]

year = {
    "Mercury":     88.0,
    "Venus"  :    224.7,
    "Earth"  :    365.2,
    "Mars"   :    687.0,
    "Jupiter":  4_331  ,
    "Saturn" : 10_747  ,
    "Uranus" : 30_589  ,
    "Neptune": 59_800  ,
}
