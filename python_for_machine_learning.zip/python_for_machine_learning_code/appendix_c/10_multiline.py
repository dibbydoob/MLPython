'''The following function is intentionally empty.
It is just a placeholder to be implemnted later.
'''
def my_function(a):
    pass
