if any([a < 5,
        a > 5,
        -2 < a < 2]):
    print("abs(a) is not in 2 to 5")
