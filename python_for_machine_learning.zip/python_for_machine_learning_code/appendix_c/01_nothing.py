for x in range(10):
    pass

for x in range(10):
    ...
