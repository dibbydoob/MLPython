months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

year, mon, day = 2022, 4, 16
print("%d %s %d" % (day, months[mon-1], year))
