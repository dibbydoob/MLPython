months = ["January", "February", "March", "April", "May", "June", "July",
          "August", "September", "October", "November", "December"]

longest_month = max(months, key=len)
print(longest_month)   # 'September'
