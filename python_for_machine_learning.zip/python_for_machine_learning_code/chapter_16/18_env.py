import os
print(os.environ["MYVALUE"])
