import sys

n = int(sys.argv[1])
print(n+1)
