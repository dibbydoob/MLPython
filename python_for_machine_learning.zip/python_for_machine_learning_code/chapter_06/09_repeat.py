import itertools

for i in itertools.repeat(3,5):
    print(i)
