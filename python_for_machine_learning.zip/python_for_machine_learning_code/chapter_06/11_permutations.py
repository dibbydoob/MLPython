import itertools

x = [1, 2, 3]
for t in itertools.permutations(x):
    print(t)
