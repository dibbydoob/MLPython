import numpy as np

X = np.random.random((100,3))
print(type(X))
print(isinstance(X, np.ndarray))
