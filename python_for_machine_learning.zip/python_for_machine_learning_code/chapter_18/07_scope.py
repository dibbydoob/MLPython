a = 1

def f(x):
    a = 2 * x
    return a

b = f(3)
print(a, b)
