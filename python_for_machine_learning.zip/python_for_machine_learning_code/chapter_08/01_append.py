longstr = ""
for x in range(1000):
  longstr += str(x)
