longstr = "".join([str(x) for x in range(1000)])
