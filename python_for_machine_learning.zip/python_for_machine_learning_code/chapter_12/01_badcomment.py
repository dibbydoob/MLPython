import datetime

timestamp = datetime.datetime.now()  # Get the current date and time
x = 0    # initialize x to zero
