def square(x: int) -> int:
    value: int = x * x
    return value
