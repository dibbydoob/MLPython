def square(x: int) -> int:
    return x * x
