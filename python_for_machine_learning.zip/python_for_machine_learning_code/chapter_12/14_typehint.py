n: int = 3.5
n = "assign a string"
