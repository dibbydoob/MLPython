def add(a, b):
    return a + b

c = add("one", "two")
