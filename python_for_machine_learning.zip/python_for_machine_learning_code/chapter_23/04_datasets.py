import seaborn as sns
print(sns.get_dataset_names())
