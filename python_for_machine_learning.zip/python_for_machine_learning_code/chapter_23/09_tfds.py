import tensorflow_datasets as tfds
print(tfds.list_builders())
