import randomsample

randomsample.main()
