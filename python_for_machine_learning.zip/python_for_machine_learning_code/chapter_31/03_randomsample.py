import random

def main():
    n = random.random()
    print(n)

if __name__ == "__main__":
    main()
