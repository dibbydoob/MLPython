class Dog:
	family = "Canine"

	def __init__(self, name, breed):
		self.name = name
		self.breed = breed

dog1 = Dog("Lassie", "Rough Collie")
print(dog1.name)
