original_list = [1, 2, 3, 4]
even_list = [i for i in original_list if i%2==0]
print(even_list)
