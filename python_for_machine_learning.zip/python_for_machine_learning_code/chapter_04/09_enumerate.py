name = ['Triangle', 'Square', 'Hexagon', 'Pentagon']

# enumerate returns two iterables
for i, n in enumerate(name):
    print(i, 'name: ', n)
