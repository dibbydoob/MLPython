original_list = [1, 2, 3, 4]
time3_list = [i*3 for i in original_list]
print(time3_list)
