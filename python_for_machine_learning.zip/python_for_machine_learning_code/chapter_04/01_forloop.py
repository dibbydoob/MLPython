original_list = [1, 2, 3, 4]
times3_list = []

for i in original_list:
    times3_list.append(i*3)
print(times3_list)
