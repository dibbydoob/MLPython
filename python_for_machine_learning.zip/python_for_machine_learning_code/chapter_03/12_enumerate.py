a = ["quick", "brown", "fox", "jumps", "over"]
for num, item in enumerate(a):
    print("item %d is %s" % (num, item))
