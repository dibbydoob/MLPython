template = "Square root of %d is %.3f"
n = 10
answer = template % (n, n**0.5)
print(answer)
