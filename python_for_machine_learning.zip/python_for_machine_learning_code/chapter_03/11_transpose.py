a = [['x', 3, 2.1], ['y', 5, 2.5], ['z', 7, 2.9]]
p,q,r = zip(*a)
print(p)
print(q)
print(r)
