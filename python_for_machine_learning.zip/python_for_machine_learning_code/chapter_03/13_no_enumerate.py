a = ["quick", "brown", "fox", "jumps", "over"]
for num in range(len(a)):
    print("item %d is %s" % (num, a[num]))
