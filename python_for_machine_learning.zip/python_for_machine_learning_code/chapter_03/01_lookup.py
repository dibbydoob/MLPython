value = 0 # This is obtained from a model

value_to_name = {0: "cat", 1: "dog"}
print("Result is %s" % value_to_name[value])
