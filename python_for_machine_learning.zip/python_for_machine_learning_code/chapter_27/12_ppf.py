from scipy.stats import norm
print(norm.ppf(0.99))
