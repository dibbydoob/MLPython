# create matrix
from numpy import array
A = array([[1, 2, 3], [4, 5, 6]])
print(A)