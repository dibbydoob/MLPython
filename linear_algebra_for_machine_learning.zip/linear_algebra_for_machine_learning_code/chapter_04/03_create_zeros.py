# create zero array
from numpy import zeros
a = zeros([3,5])
print(a)