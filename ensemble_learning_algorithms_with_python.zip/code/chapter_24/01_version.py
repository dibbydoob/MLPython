# check lightgbm library version
import lightgbm
print(lightgbm.__version__)